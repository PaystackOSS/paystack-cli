module.exports = require('@oclif/core').run
